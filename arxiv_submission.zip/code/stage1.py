"""Block 4 - Stage 1: log-linear Cobb-Douglas by OLS, then growth accounting."""
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

from config import FE, ANALYSIS_START


def fit_clustered(formula, data):
    """OLS with standard errors clustered by country."""
    groups = pd.factorize(data["country"])[0]
    return smf.ols(formula, data=data).fit(cov_type="cluster", cov_kwds={"groups": groups})


def add_logs(p):
    p = p[(p.Y > 0) & (p.K > 0) & (p.L > 0) & (p.year >= ANALYSIS_START)].copy()
    p["lnY"], p["lnK"], p["lnL"] = np.log(p.Y), np.log(p.K), np.log(p.L)
    p["lnY_L"], p["lnK_L"] = p.lnY - p.lnL, p.lnK - p.lnL
    return p


def estimate_production_function(p):
    """Unrestricted and constant-returns versions; returns table, alpha, beta."""
    free = fit_clustered(f"lnY ~ lnK + lnL + {FE}", p)
    crs = free.t_test("lnK + lnL = 1")
    rest = fit_clustered(f"lnY_L ~ lnK_L + {FE}", p)
    alpha = rest.params["lnK_L"]
    beta = 1 - alpha
    est = pd.DataFrame({
        "Estimate": [free.params["lnK"], free.params["lnL"],
                    free.params["lnK"] + free.params["lnL"], alpha, beta],
        "Std. error": [free.bse["lnK"], free.bse["lnL"], float(np.squeeze(crs.sd)),
                      rest.bse["lnK_L"], rest.bse["lnK_L"]],
    }, index=["alpha (unrestricted)", "beta (unrestricted)", "alpha + beta (unrestricted)",
            "alpha (CRS imposed)", "beta = 1 - alpha (CRS imposed)"])
    print("\nStage 1: production function (OLS, country/sector/year FE)")
    print(est.round(4))
    print(f"Test of alpha + beta = 1: p-value = {float(np.squeeze(crs.pvalue)):.4f}")
    print(f"N = {int(free.nobs)}, countries = {p.country.nunique()}")
    return est, alpha, beta


def growth_accounting(p, alpha, beta):
    """Log growth rates (percent) and the capital / labour / TFP contributions."""
    p = p.sort_values(["country", "sector", "year"]).copy()
    for v in ("Y", "K", "L"):
        p[f"g_{v}"] = 100 * p.groupby(["country", "sector"])[f"ln{v}"].diff()
    p["C_K"] = alpha * p.g_K
    p["C_L"] = beta * p.g_L
    p["C_TFP"] = p.g_Y - p.C_K - p.C_L
    return p.dropna(subset=["g_Y"])


def run(panel):
    p = add_logs(panel)
    est, alpha, beta = estimate_production_function(p)
    return growth_accounting(p, alpha, beta), est
