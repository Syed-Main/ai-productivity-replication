"""Block 3 - build the country x sector x year panel (live or synthetic)."""
import numpy as np
import pandas as pd

import api_oecd
import api_worldbank as wb
from config import (SECTORS, LABOUR_CODES, INVESTMENT_CODE, CONTROL_CODES,
                  DELTA, G_INIT)


def perpetual_inventory(inv):
    """K_t = (1 - delta) K_{t-1} + I_t, starting from K_0 = I_0 / (delta + g)."""
    inv = inv.sort_index().astype(float)
    inv = inv.reindex(range(inv.index.min(), inv.index.max() + 1)).interpolate(limit=2)
    inv = inv.dropna()
    if len(inv) < 15:
        return pd.Series(dtype=float)
    k = {inv.index[0]: inv.iloc[0] / (DELTA + G_INIT)}
    for y in inv.index[1:]:
        k[y] = (1 - DELTA) * k.get(y - 1, np.nan) + inv[y]
    return pd.Series(k)


def output_and_shares(keep):
    va, sh = [], []
    for sec, (va_code, sh_code) in SECTORS.items():
        va.append(wb.first_available(va_code, keep).rename(columns={"value": "Y"}).assign(sector=sec))
        sh.append(wb.first_available(sh_code, keep).rename(columns={"value": "share"}).assign(sector=sec))
    return pd.concat(va), pd.concat(sh)


def total_employment(keep):
    lf = wb.first_available(LABOUR_CODES["lf"], keep).rename(columns={"value": "lf"})
    un = wb.first_available(LABOUR_CODES["un"], keep).rename(columns={"value": "un"})
    e = lf.merge(un, on=["country", "year"])
    e["emp"] = e.lf * (1 - e.un / 100)
    return e[["country", "year", "emp"]]


def capital_stock(keep):
    gfcf = wb.first_available(INVESTMENT_CODE, keep)
    k = (gfcf.set_index("year").groupby("country")["value"]
             .apply(perpetual_inventory).rename("K_c").reset_index())
    k.columns = ["country", "year", "K_c"]
    return k


def controls(keep):
    out = None
    for name, code in CONTROL_CODES.items():
        d = wb.first_available(code, keep).rename(columns={"value": name})
        out = d if out is None else out.merge(d, on=["country", "year"], how="outer")
    out["ln_gdp_pc"] = np.log(out["ln_gdp_pc"])
    return out


def build_live_panel():
    keep = wb.countries()
    print("Block 3: downloading World Bank series ...")
    va, sh = output_and_shares(keep)
    p = va.merge(sh, on=["country", "year", "sector"])
    p = p.merge(total_employment(keep), on=["country", "year"])
    p["L"] = p.emp * p.share / 100 # labour by sector
    tot_l = p.groupby(["country", "year"])["L"].transform("sum")
    p = p.merge(capital_stock(keep), on=["country", "year"])
    p["K"] = p.K_c * p.L / tot_l # capital allocated by employment share
    print("Block 3: downloading OECD AI adoption ...")
    p = p.merge(api_oecd.ai_adoption(), on=["country", "year"], how="left")
    p = p.merge(controls(keep), on=["country", "year"], how="left")
    return p[["country", "sector", "year", "Y", "K", "L", "ai"] + list(CONTROL_CODES)]


def build_synthetic_panel(seed=0, true_alpha=0.4, true_theta=0.10):
    """Simulated panel with known parameters, to test the estimators."""
    rng = np.random.default_rng(seed)
    years, rows = np.arange(2000, 2024), []
    for c in range(60):
        ai_path = np.clip((years - 2008) * rng.uniform(0.5, 2.5), 0, None)
        fe = rng.normal(0, 0.5)
        for s_i, s in enumerate(SECTORS):
            lnK, lnL, lnA = rng.normal(10, 1), rng.normal(8, 1), 0.0
            for i, y in enumerate(years):
                lnK += rng.normal(0.04, 0.02)
                lnL += rng.normal(0.01, 0.015)
                lnA += 0.01 + true_theta / 100 * (ai_path[i - 1] if i else 0) + rng.normal(0, 0.02)
                lnY = lnA + true_alpha * lnK + (1 - true_alpha) * lnL + fe + 0.3 * s_i
                rows.append((f"C{c:02d}", s, y, np.exp(lnY), np.exp(lnK), np.exp(lnL),
                            ai_path[i] if y >= 2010 else np.nan,
                            np.log(5000 * np.exp(0.02 * i)) + fe + rng.normal(0, 0.1),
                            rng.normal(40, 10), rng.normal(1.5, 0.5),
                            rng.normal(60, 15), rng.normal(50, 15)))
    return pd.DataFrame(rows, columns=["country", "sector", "year", "Y", "K", "L", "ai"]
                        + list(CONTROL_CODES))
