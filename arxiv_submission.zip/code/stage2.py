"""Block 5 - Stage 2: does AI adoption explain TFP growth?"""
import pandas as pd

from config import CONTROL_CODES, FE
from stage1 import fit_clustered


def prepare(p):
    p = p.sort_values(["country", "sector", "year"]).copy()
    lo, hi = p.C_TFP.quantile([0.01, 0.99])
    p["dlnA"] = p.C_TFP.clip(lo, hi) # winsorised TFP growth, pp
    p["ai_lag"] = p.groupby(["country", "sector"])["ai"].shift(1)
    return p


def pick_controls(p):
    s0 = p.dropna(subset=["ai", "dlnA"])
    controls = [c for c in CONTROL_CODES if s0[c].notna().mean() > 0.6]
    print(f"\nStage 2 controls used: {controls}")
    return controls


def regressions(p, controls):
    ctrl, results, rows = " + ".join(controls), {}, []
    for name, var in (("Current AI", "ai"), ("Lagged AI", "ai_lag")):
        d = p.dropna(subset=["dlnA", var] + controls)
        m = fit_clustered(f"dlnA ~ {var} + {ctrl} + {FE}", d)
        results[name] = (m, d, var)
        rows.append({"Specification": name, "theta": m.params[var], "Std. error": m.bse[var],
                    "p-value": m.pvalues[var], "N": int(m.nobs),
                    "Countries": d.country.nunique(), "R2": m.rsquared})
    return pd.DataFrame(rows).set_index("Specification"), results


def ai_contribution(results):
    """C_AI = theta_hat * (AI_t - AI_{t-1})."""
    m, d, var = results["Current AI"]
    c = m.params[var] * (d.ai - d.groupby(["country", "sector"])["ai"].shift(1))
    print(f"Mean estimated AI contribution to TFP growth: {c.mean():.4f} pp per year")
    return c


def run(panel):
    p = prepare(panel)
    tab, results = regressions(p, pick_controls(p))
    print(tab.round(4))
    ai_contribution(results)
    return tab
