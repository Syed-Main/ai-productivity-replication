"""Block 0 - HTTP download with an on-disk cache, and a tee for the run log."""
import json
import os
import sys

import requests

from config import CACHE


def cached_get(url, params, cache_name, as_json=True):
    """GET a URL once and reuse the saved response on later runs."""
    path = os.path.join(CACHE, cache_name)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            txt = f.read()
    else:
        r = requests.get(url, params=params, timeout=120)
        r.raise_for_status()
        txt = r.text
        with open(path, "w", encoding="utf-8") as f:
            f.write(txt)
    return json.loads(txt) if as_json else txt


class Tee:
    """Send everything printed to the screen and to a text file."""
    def __init__(self, path):
        self.f, self.out = open(path, "w", encoding="utf-8"), sys.stdout

    def write(self, s):
        self.out.write(s)
        self.f.write(s)

    def flush(self):
        self.out.flush()
        self.f.flush()
