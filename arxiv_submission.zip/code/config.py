"""Block 0 - settings shared by every module."""
import os

WB = "https://api.worldbank.org/v2"
OECD = "https://sdmx.oecd.org/public/rest"
OECD_DATAFLOW = "OECD.STI.DEP,DSD_ICT_B@DF_BUSINESSES" # ICT access and usage by businesses
OECD_MEASURE_REGEX = r"artificial intelligence" # selects the AI-use indicator

START, END = 1990, 2024 # download window (early years feed the capital stock)
ANALYSIS_START = 2000 # first year used in the regressions
DELTA = 0.05 # depreciation rate, perpetual inventory method
G_INIT = 0.03 # assumed growth for the initial capital stock

CACHE = "cache"
OUT = "results"

# sector: (value added code(s), employment share code)
SECTORS = {
    "Agriculture": ("NV.AGR.TOTL.KD", "SL.AGR.EMPL.ZS"),
    "Industry": ("NV.IND.TOTL.KD", "SL.IND.EMPL.ZS"),
    "Services": (("NV.SRV.TOTL.KD", "NV.SRV.TETC.KD"), "SL.SRV.EMPL.ZS"),
}
LABOUR_CODES = {"lf": "SL.TLF.TOTL.IN", "un": "SL.UEM.TOTL.ZS"}
INVESTMENT_CODE = "NE.GDI.FTOT.KD" # gross fixed capital formation, constant 2015 US$
CONTROL_CODES = {
    "ln_gdp_pc": "NY.GDP.PCAP.KD", # level of development (logged in panel.py)
    "tertiary": "SE.TER.ENRR", # education
    "rd": "GB.XPD.RSDV.GD.ZS", # research expenditure, % of GDP
    "trade": "NE.TRD.GNFS.ZS", # trade openness, % of GDP
    "internet": "IT.NET.USER.ZS", # digital infrastructure
}
FE = "C(country) + C(sector) + C(year)" # fixed effects used in every regression

for d in (CACHE, OUT):
    os.makedirs(d, exist_ok=True)
