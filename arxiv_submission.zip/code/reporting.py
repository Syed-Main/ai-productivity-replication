"""Block 6 - tables (CSV and LaTeX) and figures."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from config import OUT


def to_latex(df, path, fmt="{:.3f}"):
    lines = [r"\begin{tabular}{l" + "r" * df.shape[1] + "}", r"\toprule",
             " & ".join(["{}"] + [c.replace("%", r"\%") for c in df.columns]) + r" \\",
             r"\midrule"]
    for idx in df.index:
        cells = []
        for c in df.columns:
            v = df.loc[idx, c]
            cells.append(fmt.format(v) if isinstance(v, (float, np.floating)) else str(v))
        lines.append(" & ".join([str(idx).replace("_", r"\_")] + cells) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    with open(path, "w") as f:
        f.write("\n".join(lines))


def decomposition_table(panel):
    return (panel.groupby("sector")[["g_Y", "C_K", "C_L", "C_TFP"]].mean()
                .rename(columns={"g_Y": "Output growth", "C_K": "Capital",
                                "C_L": "Labour", "C_TFP": "TFP"}))


def save_all(panel, est, tab):
    dec = decomposition_table(panel)
    for name, df, fmt in (("production_function", est, "{:.3f}"),
                        ("ai_regressions", tab, "{:.3f}"),
                        ("decomposition_by_sector", dec, "{:.2f}")):
        df.to_csv(f"{OUT}/{name}.csv")
        to_latex(df, f"{OUT}/{name}.tex", fmt)
    panel.to_csv(f"{OUT}/panel_with_decomposition.csv", index=False)
    print("\nMean annual growth decomposition (percentage points):")
    print(dec.round(2))

    ax = dec[["Capital", "Labour", "TFP"]].plot(kind="bar", stacked=True, rot=0,
                                            color=["#3182bd", "#f16913", "#31a354"],
                                            figsize=(5.5, 3.6))
    ax.set_ylabel("Mean annual contribution (pp)")
    ax.set_xlabel("")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(f"{OUT}/fig_decomposition.pdf")
    plt.close()
