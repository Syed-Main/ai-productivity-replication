"""Block 2 - OECD SDMX REST API (sdmx.oecd.org): AI adoption by businesses."""
import io

import numpy as np
import pandas as pd

from config import OECD, OECD_DATAFLOW, OECD_MEASURE_REGEX
from utils import cached_get


def parse_ai_adoption(csv_text):
    """Turn the OECD csvfilewithlabels download into a country-year AI series."""
    df = pd.read_csv(io.StringIO(csv_text), low_memory=False)
    mcols = [c for c in df.columns if "measure" in c.lower()]
    mask = np.zeros(len(df), dtype=bool)
    for c in mcols:
        mask |= df[c].astype(str).str.contains(OECD_MEASURE_REGEX, case=False,
                                            regex=True, na=False)
    df = df[mask]
    if df.empty:
        raise RuntimeError("no AI indicator found: inspect the dataflow's measure "
                          "labels and edit OECD_MEASURE_REGEX in config.py")
    # keep whole-economy / all-size breakdowns where they exist
    for c in df.columns:
        if any(k in c.upper() for k in ("ACTIVITY", "SIZE")) and "_T" in set(df[c]):
            df = df[df[c] == "_T"]
    key = mcols[0] # if several AI measures remain,
    best = df.groupby(key)["OBS_VALUE"].count().idxmax() # keep the best covered
    df = df[df[key] == best]
    print(f"OECD AI measure used: {best}")
    return (df.assign(year=pd.to_numeric(df["TIME_PERIOD"].astype(str).str[:4]))
              .groupby(["REF_AREA", "year"], as_index=False)["OBS_VALUE"].mean()
              .rename(columns={"REF_AREA": "country", "OBS_VALUE": "ai"}))


def ai_adoption():
    txt = cached_get(f"{OECD}/data/{OECD_DATAFLOW}/all",
                    {"startPeriod": "2015", "format": "csvfilewithlabels"},
                    "oecd_ict_businesses.csv", as_json=False)
    return parse_ai_adoption(txt)
