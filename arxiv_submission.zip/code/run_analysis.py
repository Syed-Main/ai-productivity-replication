"""
Run the whole analysis, block by block.

    python run_analysis.py # live World Bank + OECD APIs
    python run_analysis.py --synthetic # simulated data, pipeline test only

Blocks: 1 World Bank API 2 OECD API 3 panel 4 stage 1 5 stage 2 6 outputs
The console output is also saved to results/run_log.txt
"""
import argparse
import sys

import requests

import panel as panel_mod
import reporting
import stage1
import stage2
from config import OUT
from utils import Tee


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--synthetic", action="store_true")
    args = ap.parse_args()
    sys.stdout = Tee(f"{OUT}/run_log.txt")

    if args.synthetic:
        print("*** SYNTHETIC DATA: results validate the code only ***")
        panel = panel_mod.build_synthetic_panel()
    else:
        try:
            panel = panel_mod.build_live_panel() # blocks 1-3
        except requests.RequestException as exc:
            sys.exit(f"Could not reach the World Bank/OECD APIs: {exc}")
    print(f"Panel: {len(panel)} rows, {panel.country.nunique()} countries")

    decomposed, est = stage1.run(panel) # block 4
    tab = stage2.run(decomposed) # block 5
    reporting.save_all(decomposed, est, tab) # block 6


if __name__ == "__main__":
    main()
